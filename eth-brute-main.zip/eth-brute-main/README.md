#  Ethereum Brute Private Keys
Try to find/match Ethereum Private Key from Ethereum address list.

```
sudo apt-get install libssl-dev build-essential automake pkg-config libtool libffi-dev libgmp-dev
```
```
pip3 install -r requirements.txt
```
```
python3 eth-brute.py
```
if ethereum address match, will save on winner.txt file.

<img src="https://github.com/rouze-d/eth-brute/blob/main/screenshot.png"/>
<br>
<h2> IMPOSSIBLE !! but maybe you're God favorite person.
